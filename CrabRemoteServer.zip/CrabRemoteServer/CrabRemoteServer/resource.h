﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 CrabRemoteServer.rc 使用
//
#define IDR_SERVER_DIALOG_MAIN_TOOLBAR  4
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CRABREMOTESERVER_DIALOG     102
#define IDR_MAINFRAME                   128
#define CRAB_DIALOG_MAIN_MENU           130
#define IDR_TOOLBAR1                    131
#define IDR_SERVER_DIALOG_MAIN_TOOL_BAR 133
#define IDR_NOTIFY_ICON_DATA_MENU       133
#define IDB_SERVER_DIALOG_MAIN_BITMAP   137
#define CRAB_SERVER_INFORMATION_LIST    1000
#define CRAB_CLIENT_INFORMATION_LIST    1001
#define ID_MENU_EXIT                    32775
#define ID_MENU_SET_LOCAL               32777
#define ID_MENU_ADD_INFORMATION         32780
#define ID_CMD_MANAGER                  32781
#define ID_PROCESS_MANAGER              32782
#define ID_WINDOW_MANAGER               32783
#define ID_REMOTE_CONTROL               32784
#define ID_FILE_MANAGER                 32785
#define ID_AUDIO_MANAGER                32786
#define ID_CLEAN_MANAGER                32787
#define ID_VIDEO_MANAGER                32788
#define ID_SERVICE_MANAGER              32789
#define ID_REGISTER_MANAGER             32790
#define ID_SERVER_MANAGER               32791
#define ID_CLIENT_MANAGER               32792
#define ID_SERVER_ABOUT                 32793
#define ID_SHOW_MAIN_DIALOG             32796
#define ID_                             32797
#define ID_HIDE_MAIN_DIALOG             32798

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32800
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
